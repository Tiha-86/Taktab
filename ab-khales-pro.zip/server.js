const express=require("express"), path=require("path"), fs=require("fs");
const Database=require("better-sqlite3"), bcrypt=require("bcryptjs"), multer=require("multer"), cookieSession=require("cookie-session");
const app=express(), PORT=process.env.PORT||3000;
const db=new Database(path.join(__dirname,"data/shop.db"));
db.exec(`CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT,price INTEGER NOT NULL,image TEXT,stock INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_name TEXT,phone TEXT,address TEXT,total INTEGER,status TEXT DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,product_id INTEGER,name TEXT,price INTEGER,qty INTEGER);`);
if(!db.prepare("SELECT * FROM admins LIMIT 1").get()){
  db.prepare("INSERT INTO admins(username,password) VALUES(?,?)").run("admin",bcrypt.hashSync("Admin@12345",10));
}
if(!db.prepare("SELECT * FROM products LIMIT 1").get()){
  const add=db.prepare("INSERT INTO products(name,description,price,image,stock) VALUES(?,?,?,?,?)");
  add.run("آب مقطر ۱ لیتری","مناسب مصارف عمومی و فنی",85000,"",50);
  add.run("آب مقطر ۴ لیتری","گزینه اقتصادی برای مصرف بیشتر",245000,"",30);
  add.run("آب نانو دیونیزه","برای کاربردهای حساس و تخصصی",390000,"",20);
}
app.use(express.json()); app.use(express.urlencoded({extended:true}));
app.use(cookieSession({name:"session",keys:[process.env.SESSION_SECRET||"change-this-secret"],httpOnly:true,sameSite:"lax"}));
app.use("/uploads",express.static(path.join(__dirname,"uploads"))); app.use(express.static(path.join(__dirname,"public")));
const upload=multer({storage:multer.diskStorage({destination:(r,f,cb)=>cb(null,path.join(__dirname,"uploads")),filename:(r,f,cb)=>cb(null,Date.now()+"-"+Math.random().toString(36).slice(2)+path.extname(f.originalname))}),limits:{fileSize:3*1024*1024}});
const admin=(req,res,next)=>req.session&&req.session.admin?next():res.status(401).json({error:"ورود مدیر لازم است"});
app.get("/api/products",(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/login",(req,res)=>{const a=db.prepare("SELECT * FROM admins WHERE username=?").get(req.body.username); if(!a||!bcrypt.compareSync(req.body.password,a.password))return res.status(401).json({error:"نام کاربری یا رمز عبور نادرست است"}); req.session.admin={id:a.id,username:a.username}; res.json({ok:true});});
app.post("/api/logout",(req,res)=>{req.session=null;res.json({ok:true})});
app.get("/api/me",(req,res)=>res.json({admin:req.session?.admin||null}));
app.post("/api/products",admin,upload.single("image"),(req,res)=>{const p=db.prepare("INSERT INTO products(name,description,price,image,stock) VALUES(?,?,?,?,?)").run(req.body.name,req.body.description||"",Number(req.body.price),req.file?"/uploads/"+req.file.filename:"",Number(req.body.stock||0));res.json(db.prepare("SELECT * FROM products WHERE id=?").get(p.lastInsertRowid));});
app.put("/api/products/:id",admin,upload.single("image"),(req,res)=>{const old=db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id);if(!old)return res.status(404).json({error:"محصول پیدا نشد"});const image=req.file?"/uploads/"+req.file.filename:old.image;db.prepare("UPDATE products SET name=?,description=?,price=?,image=?,stock=? WHERE id=?").run(req.body.name,req.body.description||"",Number(req.body.price),image,Number(req.body.stock||0),req.params.id);res.json({ok:true});});
app.delete("/api/products/:id",admin,(req,res)=>{db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);res.json({ok:true})});
app.get("/api/orders",admin,(req,res)=>res.json(db.prepare("SELECT * FROM orders ORDER BY id DESC").all()));
app.put("/api/orders/:id",admin,(req,res)=>{db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);res.json({ok:true})});
app.post("/api/orders",(req,res)=>{const {name,phone,address,items}=req.body;if(!name||!phone||!address||!Array.isArray(items)||!items.length)return res.status(400).json({error:"اطلاعات سفارش کامل نیست"});let total=0;const checked=[];for(const i of items){const p=db.prepare("SELECT * FROM products WHERE id=?").get(i.id);const q=Math.max(1,Number(i.qty));if(!p||p.stock<q)return res.status(400).json({error:"موجودی یکی از محصولات کافی نیست"});total+=p.price*q;checked.push({p,q});}const o=db.prepare("INSERT INTO orders(customer_name,phone,address,total) VALUES(?,?,?,?)").run(name,phone,address,total);const add=db.prepare("INSERT INTO order_items(order_id,product_id,name,price,qty) VALUES(?,?,?,?,?)");const dec=db.prepare("UPDATE products SET stock=stock-? WHERE id=?");for(const x of checked){add.run(o.lastInsertRowid,x.p.id,x.p.name,x.p.price,x.q);dec.run(x.q,x.p.id)}res.json({ok:true,orderId:o.lastInsertRowid,total});});
app.get("/admin",(_,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.listen(PORT,()=>console.log("http://localhost:"+PORT));